# Currency Converter API (.NET 8)

A robust Currency Converter API built with .NET 8 that provides currency conversion functionality using local exchange rates.

## Features

- Currency conversion with support for multiple currencies
- Local exchange rates management via JSON file
- Swagger UI for API documentation and testing
- Comprehensive error handling
- Structured logging with Serilog
- Unit tests using xUnit

## Prerequisites

- .NET 8 SDK
- Visual Studio 2022 or VS Code

## Project Structure
```
Currencies and tests are in the solution root. Main project: `CurrencyConverterApi`. Tests: `CurrencyConverterApi.Tests`.
```

## Build & run

From PowerShell (project root):

```powershell
# Build the API
dotnet build "CurrencyConverterApi/CurrencyConverterApi.csproj" -c Debug

# Run the API (starts Kestrel, Swagger enabled in Development)
dotnet run --project "CurrencyConverterApi/CurrencyConverterApi.csproj" --configuration Debug
```

When started the app logs the listening URL, e.g. `http://localhost:5047`.

## Tests

Run unit tests:

```powershell
dotnet test "CurrencyConverterApi.Tests/CurrencyConverterApi.Tests.csproj" -v minimal
```

There is a small `TestData/exchangeRates.json` used by the test project; ensure it exists under `CurrencyConverterApi.Tests/TestData`.

## API Endpoints (examples)

- GET /api/currency/rates — returns the current exchange rates (JSON)
- POST /api/currency/convert — converts an amount; sample body:

```json
{
	"fromCurrency": "USD",
	"toCurrency": "EUR",
	"amount": 100
}
```
- PUT /api/currency/rates — updates an amount; sample body:
```json
{
  "baseCurrency": "USD",
  "rates": {
    "EUR": 0.85,
    "INR": 74
  },
  "lastUpdated": "2025-10-28T17:13:49.518Z"
}
````

Example PowerShell calls:

```powershell
Invoke-RestMethod -Method Get -Uri http://localhost:5047/api/currency/rates

Invoke-RestMethod -Method Post -Uri http://localhost:5047/api/currency/convert -ContentType 'application/json' -Body (@{ FromCurrency='USD'; ToCurrency='EUR'; Amount=100 } | ConvertTo-Json)
```

## Notes about recent code changes

While fixing test/build issues I made a few small, backward-compatible changes to make the project easier to run and test locally:

- Added a convenience constructor to `CurrencyController` for tests. At runtime the constructor that accepts `IWebHostEnvironment` is used (marked with `[ActivatorUtilitiesConstructor]`) to avoid DI ambiguity.
- Added an `IConfiguration`-based constructor and DTO overloads to `CurrencyConverterService` to support test scenarios that pass a path via configuration.
- To avoid DI constructor ambiguity at startup, `Program.cs` registers the service with a factory that constructs `CurrencyConverterService` using `IWebHostEnvironment`.
- Added `CurrencyConverterApi.Tests/TestData/exchangeRates.json` which contains sample rates used by unit tests.

These changes are intended to be low-risk; if you prefer to keep production code minimal we can refactor tests to inject `IWebHostEnvironment` mocks instead and remove the test-specific constructors.

## Troubleshooting

- "Multiple constructors" DI error: happens when more than one constructor matches DI services. The runtime constructor is explicitly marked with `[ActivatorUtilitiesConstructor]` and registration uses a factory to avoid ambiguity.
- "File not found" for exchange rates: ensure `exchangeRates.json` exists in the app content root (project root when running via `dotnet run`) or update the path in `appsettings.json` / test configuration.

## Next steps (optional)

- Add more unit tests for edge cases (zero amount, same currency, unsupported currency).
- Add integration tests that run the app in-memory and exercise endpoints.
- Replace test-specific constructors with test helpers that construct required dependencies (recommended if you want a cleaner production API surface).
