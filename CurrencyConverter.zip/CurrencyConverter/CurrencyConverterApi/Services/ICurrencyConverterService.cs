using CurrencyConverterApi.Models;
using CurrencyConverterApi.DTOs;

namespace CurrencyConverterApi.Services;

public interface ICurrencyConverterService
{
    Task<ExchangeRate> GetExchangeRatesAsync();
    Task<decimal> ConvertCurrencyAsync(string fromCurrency, string toCurrency, decimal amount);
    Task ReloadAsync();
    // Additional convenience API used by tests and callers
    Task<CurrencyConversionResponse> ConvertCurrencyAsync(CurrencyConversionRequest request);
    Task<IDictionary<string, decimal>> GetAvailableRatesAsync();
}