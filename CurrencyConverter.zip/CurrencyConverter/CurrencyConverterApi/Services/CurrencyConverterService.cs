using System.Text.Json;
using CurrencyConverterApi.Models;
using CurrencyConverterApi.DTOs;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System.Linq;

namespace CurrencyConverterApi.Services;

public class CurrencyConverterService : ICurrencyConverterService
{
    private readonly ILogger<CurrencyConverterService> _logger;
    private readonly string _exchangeRatesPath;
    private readonly SemaphoreSlim _semaphore = new(1, 1);
    private ExchangeRate? _cachedRates;
    private FileSystemWatcher? _watcher;
    private DateTime _lastReload = DateTime.MinValue;

    public CurrencyConverterService(ILogger<CurrencyConverterService> logger, IWebHostEnvironment environment)
    {
        _logger = logger;
        _exchangeRatesPath = Path.Combine(environment.ContentRootPath, "exchangeRates.json");
        
        // Ensure the file exists and log its absolute path
        _logger.LogInformation("ContentRootPath: {ContentRootPath}", environment.ContentRootPath);
        _logger.LogInformation("Exchange rates file path: {FilePath}", _exchangeRatesPath);
        _logger.LogInformation("File exists: {FileExists}", File.Exists(_exchangeRatesPath));
        
        if (File.Exists(_exchangeRatesPath))
        {
            var content = File.ReadAllText(_exchangeRatesPath);
            _logger.LogInformation("File content: {Content}", content);
        }

        // Load initially and start file watcher to reload on changes
        _ = LoadFromFileAsync();
        InitializeWatcher();
    }

    // Constructor used in tests where an IConfiguration points to a test data file
    [ActivatorUtilitiesConstructor]
    public CurrencyConverterService(ILogger<CurrencyConverterService> logger, IConfiguration config)
    {
        _logger = logger;
        var configuredPath = config["ExchangeRatesPath"] ?? "exchangeRates.json";
        _exchangeRatesPath = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, configuredPath));

        _logger.LogInformation("Using exchange rates path from config: {Path}", _exchangeRatesPath);

        // Load initially and start watcher
        _ = LoadFromFileAsync();
        InitializeWatcher();
    }

    private void InitializeWatcher()
    {
        try
        {
            var dir = Path.GetDirectoryName(_exchangeRatesPath) ?? ".";
            var file = Path.GetFileName(_exchangeRatesPath);
            _watcher = new FileSystemWatcher(dir, file)
            {
                NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.Size | NotifyFilters.FileName
            };

            // Debounced reload on change/rename/create
            _watcher.Changed += async (_, __) => await OnFileChangedAsync();
            _watcher.Renamed += async (_, __) => await OnFileChangedAsync();
            _watcher.Created += async (_, __) => await OnFileChangedAsync();
            _watcher.EnableRaisingEvents = true;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to initialize FileSystemWatcher for exchange rates");
        }
    }

    private async Task OnFileChangedAsync()
    {
        // debounce rapid events
        var now = DateTime.UtcNow;
        if ((now - _lastReload).TotalMilliseconds < 500)
            return;

        _lastReload = now;
        try
        {
            await LoadFromFileAsync();
            _logger.LogInformation("Exchange rates reloaded due to file change");
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to reload exchange rates after file change");
        }
    }

    public async Task<ExchangeRate> GetExchangeRatesAsync()
    {
        // Return cached rates if available
        if (_cachedRates != null)
            return _cachedRates;

        await _semaphore.WaitAsync();
        try
        {
            if (_cachedRates != null)
                return _cachedRates;

            var loaded = await LoadFromFileAsync();
            if (loaded == null)
                throw new InvalidOperationException("Exchange rates not available");

            _cachedRates = loaded;
            return _cachedRates;
        }
        finally
        {
            _semaphore.Release();
        }
    }

    public async Task ReloadAsync()
    {
        await _semaphore.WaitAsync();
        try
        {
            _cachedRates = await LoadFromFileAsync();
            _logger.LogInformation("Manual reload completed. BaseCurrency={Base}", _cachedRates?.BaseCurrency);
        }
        finally
        {
            _semaphore.Release();
        }
    }

    private async Task<ExchangeRate?> LoadFromFileAsync()
    {
        try
        {
            _logger.LogInformation("Exchange rates file path: {FilePath}", _exchangeRatesPath);

            if (!File.Exists(_exchangeRatesPath))
            {
                _logger.LogError("Exchange rates file not found at path: {FilePath}", _exchangeRatesPath);
                return null;
            }

            _logger.LogInformation("Reading exchange rates from file");
            var jsonString = await File.ReadAllTextAsync(_exchangeRatesPath);
            _logger.LogInformation("File content: {Content}", jsonString);

            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };

            var exchangeRates = JsonSerializer.Deserialize<ExchangeRate>(jsonString, options);
            if (exchangeRates == null)
            {
                _logger.LogError("Failed to deserialize exchange rates");
                return null;
            }

            if (string.IsNullOrEmpty(exchangeRates.BaseCurrency))
            {
                _logger.LogError("Base currency is missing in the exchange rates file");
                return null;
            }

            if (exchangeRates.Rates == null || exchangeRates.Rates.Count == 0)
            {
                _logger.LogError("No exchange rates found in the file");
                return null;
            }

            _logger.LogInformation("Successfully loaded exchange rates: BaseCurrency={BaseCurrency}, RateCount={RateCount}", 
                exchangeRates.BaseCurrency, exchangeRates.Rates.Count);

            return exchangeRates;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error reading exchange rates from {FilePath}", _exchangeRatesPath);
            return null;
        }
    }

public async Task<decimal> ConvertCurrencyAsync(string fromCurrency, string toCurrency, decimal amount)
    {
        try
        {
            var exchangeRates = await GetExchangeRatesAsync();
            
            _logger.LogInformation("Exchange Rates Content: BaseCurrency={BaseCurrency}, Rates={Rates}", 
                exchangeRates.BaseCurrency, 
                System.Text.Json.JsonSerializer.Serialize(exchangeRates.Rates));
            
            _logger.LogInformation("Converting from {FromCurrency} to {ToCurrency}, Amount={Amount}", 
                fromCurrency, toCurrency, amount);

            // Case-insensitive currency comparison
            fromCurrency = fromCurrency.ToUpperInvariant();
            toCurrency = toCurrency.ToUpperInvariant();
            
            bool isFromCurrencyValid = exchangeRates.Rates.ContainsKey(fromCurrency) || 
                fromCurrency.Equals(exchangeRates.BaseCurrency, StringComparison.OrdinalIgnoreCase);
            bool isToCurrencyValid = exchangeRates.Rates.ContainsKey(toCurrency) || 
                toCurrency.Equals(exchangeRates.BaseCurrency, StringComparison.OrdinalIgnoreCase);

            _logger.LogInformation("Currency validation: FromCurrency={FromValid}, ToCurrency={ToValid}", 
                isFromCurrencyValid, isToCurrencyValid);

            if (!isFromCurrencyValid)
            {
                _logger.LogWarning("FromCurrency {FromCurrency} not found in rates. Available currencies: {Currencies}", 
                    fromCurrency, string.Join(", ", exchangeRates.Rates.Keys.Concat(new[] { exchangeRates.BaseCurrency })));
                throw new ArgumentException($"Currency {fromCurrency} is not supported");
            }         
            if (!isToCurrencyValid)
            {
                _logger.LogWarning("ToCurrency {ToCurrency} not found in rates. Available currencies: {Currencies}", 
                    toCurrency, string.Join(", ", exchangeRates.Rates.Keys.Concat(new[] { exchangeRates.BaseCurrency })));
                throw new ArgumentException($"Currency {toCurrency} is not supported");
            }

            decimal result;
            
            // Convert from base currency
            if (fromCurrency == exchangeRates.BaseCurrency)
            {
                result = amount * exchangeRates.Rates[toCurrency];
            }
            // Convert to base currency
            else if (toCurrency == exchangeRates.BaseCurrency)
            {
                result = amount / exchangeRates.Rates[fromCurrency];
            }
            // Convert between two non-base currencies
            else
            {
                var amountInBaseCurrency = amount / exchangeRates.Rates[fromCurrency];
                result = amountInBaseCurrency * exchangeRates.Rates[toCurrency];
            }

            _logger.LogInformation("Converted {Amount} {FromCurrency} to {Result} {ToCurrency}", 
                amount, fromCurrency, result, toCurrency);

            return Math.Round(result, 4);
        }
        catch (Exception ex) when (ex is not ArgumentException)
        {
            _logger.LogError(ex, "Error converting currency");
            throw new InvalidOperationException("Currency conversion failed", ex);
        }
    }

    // DTO-based overload used by tests and higher-level callers
    public async Task<CurrencyConversionResponse> ConvertCurrencyAsync(CurrencyConversionRequest request)
    {
        if (request == null)
            throw new ArgumentNullException(nameof(request));

        var converted = await ConvertCurrencyAsync(request.FromCurrency, request.ToCurrency, request.Amount);

        return new CurrencyConversionResponse
        {
            FromCurrency = request.FromCurrency,
            ToCurrency = request.ToCurrency,
            Amount = request.Amount,
            ConvertedAmount = converted,
            ExchangeRate = request.Amount != 0 ? converted / request.Amount : 0m,
            ConversionTime = DateTime.UtcNow
        };
    }

    public async Task<IDictionary<string, decimal>> GetAvailableRatesAsync()
    {
        var exchangeRates = await GetExchangeRatesAsync();
        var dict = new Dictionary<string, decimal>(StringComparer.OrdinalIgnoreCase);
        foreach (var kvp in exchangeRates.Rates)
            dict[kvp.Key] = kvp.Value;

        if (!dict.ContainsKey(exchangeRates.BaseCurrency))
            dict[exchangeRates.BaseCurrency] = 1m;

        return dict;
    }
}