using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using CurrencyConverterApi.Services;
using CurrencyConverterApi.DTOs;
using CurrencyConverterApi.Models;
using System.IO;
using System.Text.Json;

namespace CurrencyConverterApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CurrencyController : ControllerBase
{
    private readonly ICurrencyConverterService _currencyService;
    private readonly ILogger<CurrencyController> _logger;
    private readonly string _exchangeRatesPath;

    [ActivatorUtilitiesConstructor]
    public CurrencyController(ICurrencyConverterService currencyService, ILogger<CurrencyController> logger, IWebHostEnvironment environment)
    {
        _currencyService = currencyService;
        _logger = logger;
        _exchangeRatesPath = Path.Combine(environment.ContentRootPath, "exchangeRates.json");
    }

    // Convenience constructor used by tests or environments where IWebHostEnvironment
    // isn't available. Falls back to current directory as the content root.
    public CurrencyController(ICurrencyConverterService currencyService, ILogger<CurrencyController> logger)
    {
        _currencyService = currencyService;
        _logger = logger;
        _exchangeRatesPath = Path.Combine(Directory.GetCurrentDirectory(), "exchangeRates.json");
    }

    /// <summary>
    /// Get all available exchange rates
    /// </summary>
    /// <returns>Current exchange rates for all supported currencies</returns>
    /// <response code="200">Returns the exchange rates</response>
    /// <response code="500">If there was an internal error</response>
    [HttpGet("rates")]
    [ProducesResponseType(typeof(ExchangeRate), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<ActionResult<ExchangeRate>> GetExchangeRates()
    {
        try
        {
            var rates = await _currencyService.GetExchangeRatesAsync();
            return Ok(rates);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving exchange rates");
            return StatusCode(500, "An error occurred while retrieving exchange rates");
        }
    }

    /// <summary>
    /// Convert an amount from one currency to another
    /// </summary>
    /// <param name="request">Currency conversion request details</param>
    /// <returns>Converted amount and exchange rate details</returns>
    /// <response code="200">Returns the conversion result</response>
    /// <response code="400">If the request is invalid</response>
    /// <response code="500">If there was an internal error</response>
    [HttpPost("convert")]
    [ProducesResponseType(typeof(CurrencyConversionResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<ActionResult<CurrencyConversionResponse>> ConvertCurrency(CurrencyConversionRequest request)
    {
        try
        {
            if (request.Amount <= 0)
                return BadRequest("Amount must be greater than zero");

            if (string.IsNullOrEmpty(request.FromCurrency) || string.IsNullOrEmpty(request.ToCurrency))
                return BadRequest("Both FromCurrency and ToCurrency are required");

            // Normalize currency codes to uppercase
            request.FromCurrency = request.FromCurrency.ToUpperInvariant();
            request.ToCurrency = request.ToCurrency.ToUpperInvariant();

            _logger.LogInformation("Converting {Amount} from {FromCurrency} to {ToCurrency}", 
                request.Amount, request.FromCurrency, request.ToCurrency);

            var convertedAmount = await _currencyService.ConvertCurrencyAsync(
                request.FromCurrency,
                request.ToCurrency,
                request.Amount);

            var response = new CurrencyConversionResponse
            {
                FromCurrency = request.FromCurrency,
                ToCurrency = request.ToCurrency,
                Amount = request.Amount,
                ConvertedAmount = convertedAmount,
                ExchangeRate = convertedAmount / request.Amount,
                ConversionTime = DateTime.UtcNow
            };

            return Ok(response);
        }
        catch (ArgumentException ex)
        {
            _logger.LogWarning(ex, "Invalid currency conversion request");
            return BadRequest(ex.Message);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error converting currency");
            return StatusCode(500, "An error occurred while converting the currency");
        }
    }

    /// <summary>
    /// Update exchange rates with new data
    /// </summary>
    /// <param name="exchangeRate">New exchange rate data</param>
    [HttpPut("rates")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> UpdateExchangeRates(ExchangeRate exchangeRate)
    {
        try
        {
            if (string.IsNullOrEmpty(exchangeRate.BaseCurrency))
                return BadRequest("Base currency is required");

            if (exchangeRate.Rates == null || exchangeRate.Rates.Count == 0)
                return BadRequest("At least one exchange rate is required");

            // Normalize currency codes
            exchangeRate.BaseCurrency = exchangeRate.BaseCurrency.ToUpperInvariant();
            var normalizedRates = exchangeRate.Rates.ToDictionary(
                kvp => kvp.Key.ToUpperInvariant(),
                kvp => kvp.Value
            );
            exchangeRate.Rates = normalizedRates;

            // Update the exchange rates file
            var json = JsonSerializer.Serialize(exchangeRate, new JsonSerializerOptions 
            { 
                WriteIndented = true 
            });
            await System.IO.File.WriteAllTextAsync(_exchangeRatesPath, json);

            // Reload rates from the updated file
            await _currencyService.ReloadAsync();
            return NoContent();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error updating exchange rates");
            return StatusCode(500, "Failed to update exchange rates");
        }
    }
}