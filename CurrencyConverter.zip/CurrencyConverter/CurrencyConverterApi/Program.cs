using CurrencyConverterApi.Services;

var builder = WebApplication.CreateBuilder(args);

// Add CORS
builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

// Add services to the container.
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "Currency Converter API",
        Version = "v1",
        Description = "An API for converting between different currencies"
    });
});

// Add logging
builder.Logging.ClearProviders();
builder.Logging.AddConsole();
builder.Logging.AddDebug();

// Register services
// Use a factory to explicitly construct CurrencyConverterService with IWebHostEnvironment
// to avoid constructor ambiguity for DI (there is also an IConfiguration-based ctor used in tests).
builder.Services.AddSingleton<ICurrencyConverterService>(sp =>
    new CurrencyConverterService(sp.GetRequiredService<ILogger<CurrencyConverterService>>(),
        sp.GetRequiredService<IWebHostEnvironment>()));

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// Enable CORS
app.UseCors();

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();

app.Run();