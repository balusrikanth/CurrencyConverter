global using System.Text.Json;
global using Microsoft.AspNetCore.Mvc;
global using Microsoft.OpenApi.Models;
global using CurrencyConverterApi.Models;
global using CurrencyConverterApi.Services;