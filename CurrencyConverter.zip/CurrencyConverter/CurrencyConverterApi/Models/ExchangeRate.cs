namespace CurrencyConverterApi.Models;

public class ExchangeRate
{
    public string BaseCurrency { get; set; } = string.Empty;
    public Dictionary<string, decimal> Rates { get; set; } = new();
    public DateTime LastUpdated { get; set; }
}