using Microsoft.AspNetCore.Mvc;
using Xunit;
using Moq;
using Microsoft.Extensions.Logging;
using CurrencyConverterApi.Controllers;
using CurrencyConverterApi.Services;
using CurrencyConverterApi.DTOs;
using System.Threading.Tasks;
using System;

namespace CurrencyConverterApi.Tests;

public class CurrencyControllerTests
{
    private readonly Mock<ICurrencyConverterService> _serviceMock;
    private readonly Mock<ILogger<CurrencyController>> _loggerMock;
    private readonly CurrencyController _controller;

    public CurrencyControllerTests()
    {
        _serviceMock = new Mock<ICurrencyConverterService>();
        _loggerMock = new Mock<ILogger<CurrencyController>>();
        _controller = new CurrencyController(_serviceMock.Object, _loggerMock.Object);
    }

    [Fact]
    public async Task GetExchangeRates_ReturnsOkResult()
    {
        // Arrange
        var exchangeRates = new Models.ExchangeRate
        {
            BaseCurrency = "USD",
            Rates = new Dictionary<string, decimal> { { "EUR", 0.85m } }
        };
        _serviceMock.Setup(s => s.GetExchangeRatesAsync())
            .ReturnsAsync(exchangeRates);

        // Act
        var result = await _controller.GetExchangeRates();

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var returnValue = Assert.IsType<Models.ExchangeRate>(okResult.Value);
        Assert.Equal(exchangeRates.BaseCurrency, returnValue.BaseCurrency);
        Assert.Equal(exchangeRates.Rates, returnValue.Rates);
    }

    [Fact]
    public async Task ConvertCurrency_WithValidRequest_ReturnsOkResult()
    {
        // Arrange
        var request = new CurrencyConversionRequest
        {
            FromCurrency = "USD",
            ToCurrency = "EUR",
            Amount = 100
        };
        var expectedConvertedAmount = 85m;

        _serviceMock.Setup(s => s.ConvertCurrencyAsync(
                request.FromCurrency,
                request.ToCurrency,
                request.Amount))
            .ReturnsAsync(expectedConvertedAmount);

        // Act
        var result = await _controller.ConvertCurrency(request);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var response = Assert.IsType<CurrencyConversionResponse>(okResult.Value);
        Assert.Equal(expectedConvertedAmount, response.ConvertedAmount);
        Assert.Equal(request.FromCurrency, response.FromCurrency);
        Assert.Equal(request.ToCurrency, response.ToCurrency);
        Assert.Equal(request.Amount, response.Amount);
    }

    [Fact]
    public async Task ConvertCurrency_WithInvalidAmount_ReturnsBadRequest()
    {
        // Arrange
        var request = new CurrencyConversionRequest
        {
            FromCurrency = "USD",
            ToCurrency = "EUR",
            Amount = 0
        };

        // Act
        var result = await _controller.ConvertCurrency(request);

        // Assert
        Assert.IsType<BadRequestObjectResult>(result.Result);
    }

    [Fact]
    public async Task ConvertCurrency_WithInvalidCurrency_ReturnsBadRequest()
    {
        // Arrange
        var request = new CurrencyConversionRequest
        {
            FromCurrency = "INVALID",
            ToCurrency = "EUR",
            Amount = 100
        };

        _serviceMock.Setup(s => s.ConvertCurrencyAsync(
                request.FromCurrency,
                request.ToCurrency,
                request.Amount))
            .ThrowsAsync(new ArgumentException("Invalid currency"));

        // Act
        var result = await _controller.ConvertCurrency(request);

        // Assert
        Assert.IsType<BadRequestObjectResult>(result.Result);
    }
}