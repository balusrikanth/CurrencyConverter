using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using Moq;
using Xunit;
using CurrencyConverterApi.Services;
using CurrencyConverterApi.DTOs;

namespace CurrencyConverterApi.Tests
{
    public class CurrencyConverterServiceTests
    {
        private readonly Mock<ILogger<CurrencyConverterService>> _loggerMock;
        private readonly Mock<IConfiguration> _configMock;
        private readonly CurrencyConverterService _service;

        public CurrencyConverterServiceTests()
        {
            _loggerMock = new Mock<ILogger<CurrencyConverterService>>();
            _configMock = new Mock<IConfiguration>();
            _configMock.Setup(x => x["ExchangeRatesPath"]).Returns("../../../TestData/exchangeRates.json");
            _service = new CurrencyConverterService(_loggerMock.Object, _configMock.Object);
        }

        [Fact]
        public async Task ConvertCurrency_ValidRequest_ReturnsCorrectConversion()
        {
            // Arrange
            var request = new CurrencyConversionRequest
            {
                FromCurrency = "USD",
                ToCurrency = "EUR",
                Amount = 100
            };

            // Act
            var result = await _service.ConvertCurrencyAsync(request);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(request.FromCurrency, result.FromCurrency);
            Assert.Equal(request.ToCurrency, result.ToCurrency);
            Assert.Equal(request.Amount, result.Amount);
            Assert.Equal(93m, result.ConvertedAmount);
        }

        [Fact]
        public async Task ConvertCurrency_InvalidCurrency_ThrowsArgumentException()
        {
            // Arrange
            var request = new CurrencyConversionRequest
            {
                FromCurrency = "USD",
                ToCurrency = "INVALID",
                Amount = 100
            };

            // Act & Assert
            await Assert.ThrowsAsync<ArgumentException>(() => 
                _service.ConvertCurrencyAsync(request));
        }

        [Fact]
        public async Task GetAvailableRates_ReturnsAllRates()
        {
            // Act
            var rates = await _service.GetAvailableRatesAsync();

            // Assert
            Assert.NotNull(rates);
            Assert.Contains("EUR", rates.Keys);
            Assert.Contains("GBP", rates.Keys);
            Assert.Contains("INR", rates.Keys);
            Assert.Contains("JPY", rates.Keys);
        }
    }
}