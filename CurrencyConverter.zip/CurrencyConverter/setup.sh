# Create solution and projects
dotnet new sln -n CurrencyConverterApi
dotnet new webapi -n CurrencyConverterApi
dotnet new xunit -n CurrencyConverterApi.Tests
dotnet sln add CurrencyConverterApi/CurrencyConverterApi.csproj
dotnet sln add CurrencyConverterApi.Tests/CurrencyConverterApi.Tests.csproj
cd CurrencyConverterApi
dotnet add package Swashbuckle.AspNetCore
dotnet add package Serilog.AspNetCore
dotnet add package Serilog.Sinks.Console
dotnet add package Serilog.Sinks.File
cd ../CurrencyConverterApi.Tests
dotnet add package Moq
dotnet add package Microsoft.NET.Test.Sdk
dotnet add package xunit
dotnet add package xunit.runner.visualstudio
dotnet add reference ../CurrencyConverterApi/CurrencyConverterApi.csproj